import com.sap.gateway.ip.core.customdev.util.Message;
    import groovy.json.JsonSlurper
    
    def Message processData(Message message) {
        
        String body = message.getBody(String);

        def json = new JsonSlurper().parseText(body)

        def movementType = message.getProperty("p_movementType")

        def value = json.availableVehicles

        def newValue

        if(movementType == "Check-in"){
            newValue = value - 1
        }else {
            newValue = value + 1
        }
        
        if (value < 10){
            message.setProperty('p_low_storage_notification', true)
        } else {
            message.setProperty('p_low_storage_notification', false)
        }

        message.setProperty("p_new_value", newValue)


        return message;
        }