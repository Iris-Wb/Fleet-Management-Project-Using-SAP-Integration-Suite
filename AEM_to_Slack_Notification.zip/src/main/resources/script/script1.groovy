package script
import com.sap.gateway.ip.core.customdev.util.Message;

Message processData(Message message) {
    def body = message.getBody(String)
    
    def unicodeBody = body.collect { ch ->
        if (ch.codePointAt(0) > 127) {
            String.format("\\u%04x", (int) ch)
        } else {
            ch
        }
    }.join("")
    
    message.setBody(unicodeBody)
    
    message.setHeader("Content-Type", "application/json; charset-UTF-8")
    
    return message
    
}